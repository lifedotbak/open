package test;

public class DispPosBM {

}
